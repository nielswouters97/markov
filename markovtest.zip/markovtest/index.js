//Say
const say = require("say");
const MarkovChain = require("markovchain-generate");

//Express
var express = require("express");
var app = express();

//Twitter
var async = require("async");
var whilst = require("async/whilst");

//Textfile
var fs = require("fs");

//Max length (tweets)
var limit = require("limit-string-length");

//Txt verwijderen voordat 't opniew aangemaakt wordt
if (fs.existsSync("output.txt")) {
  // Do something
  fs.unlinkSync('output.txt');
}

//Aanmaken txt
function myWrite(data) {
  
  //https://stackoverflow.com/questions/23571013/how-to-remove-url-from-a-string-completely-in-javascript  .replace(/(?:https?|ftp):\/\/[\n\S]+/g, '');
  //https://stackoverflow.com/questions/20731966/regex-remove-all-special-characters-except-numbers
  
  //Filteren op links
  var links = /(?:https?|ftp):\/\/[\n\S]+/g;
  
  //Filteren op Speciale chars
  var special = /[@]/g

  var badText = data.toString(); //Links weghalen
  //var goodText = badText.replace(links, '');
  
  var atText = badText.replace(special, '');  //@ weghalen
  var goodText = atText.replace(links, '');

  fs.appendFile('output.txt', goodText, function (err) {
    if (err) { /* Do whatever is appropriate if append fails*/ }
  });
}

//keys aanmaken https://apps.twitter.com/app/new
//Twitter login
var Twit = require("twit");
var T = new Twit({
  consumer_key: //"Vervangen door eigen key",
  consumer_secret: //"Vervangen door eigen key",
  access_token: //"Vervangen door eigen key",
  access_token_secret: //"Vervangen door eigen key",
  timeout_ms: 60 * 1000, // optional HTTP request timeout to apply to all requests.
});

//Twitter
var count = 0;
var tweets;
var max_id = -1;
var name = "nielswouterss";
//var name = "subtiv";

//Tweets ophalen
//https://github.com/ttezel/twit/issues/338
T.get("statuses/user_timeline", {
  screen_name: name,
  count: 200 //Per 200 tweets ophalen
}, function (err, data, response) {
  console.log("\n**********BEZIG MET HET LADEN VAN DE TWEETS VAN **********\n@" + name);
  //printTweets(data)  
  printTweets(data);

  max_id = data[data.length - 1].id_str;
  async.whilst(function () {
      return max_id;
    }, function (callback) {
      T.get("statuses/user_timeline", {
          screen_name: name,
          count: 200, //Per 200 tweets ophalen
          max_id: max_id
        },
        function (err, data, response) {
          //printTweets(data)  
          printTweets(data);

          //console.log(data);

          if (data.length > 1) {
            max_id = data[data.length - 1].id_str;
          } else {
            max_id = 0;
          }
          callback();
        });
    },
    function (err) {
      console.log("\n**********GELADEN**********\n" + "AANTAL TWEETS: " + count);
    });

  //Tweets in text file zetten
  function printTweets(data) {
    for (var i = 0; i < data.length; i++) {
      //Loggen in console
      //console.log(count + " " + data[i].text);
      count++;

      //In text file zetten
      myWrite(" " + data[i].text);
    }
  }
});

//Serves main page 
app.get("/", function (req, res) {

  //https://www.npmjs.com/package/markovchain-generate
  //For an empty chain, use an empty constructor.
  var chain = new MarkovChain()

  //https://stackoverflow.com/questions/12752622/require-file-as-string
  require.extensions[".txt"] = function (module, filename) {
    module.exports = fs.readFileSync(filename, "utf8");
  };

  //Random tekst maken vanuit txt file
  //Max length voor twitter
  var text = require("./output.txt");
  chain.generateChain(text);

  //Random strings genereren
  var fakeText = chain.generateString();

  //Praten
  //Ellen is Belgische stem
  say.speak(fakeText, "Ellen");
  //say.speak(fakeText, 'Alex');

  res.sendfile("index.html");

  //De random tekst op mijn feed plaatsen
  //https://twitter.com/NielsWouterss

  if (fakeText.length <= 140) {
    T.post('statuses/update', {
      status: "Niels' bot zegt: " + fakeText
    }, function (err, data, response) {
      console.log(data);
    });
    console.log("\n**********TEKST IS " + fakeText.length + " TEKENS**********\n**********TWEET GEPLAATST**********\n**********" + fakeText + "**********\n");
  } else {
    console.log("\n**********TEKST IS " + fakeText.length + "TEKENS**********\n**********TWEET NIET GEPLAATST**********\n");
  };

  //Return fakeText in html
  res.send('<p class="tekst">' + fakeText + '</p>');
});

//Poort 5000 open zetten op localhost
var port = process.env.PORT || 5000;
app.listen(port, function () {
  console.log("Listening on " + port);
});